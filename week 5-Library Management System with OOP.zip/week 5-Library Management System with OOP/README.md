# 📚 Library Management System

A comprehensive Object-Oriented Programming (OOP) project demonstrating a real-world library management system built with Python.

## Features

### Core Functionality
- 📖 **Book Management**: Add, remove, and track books
- 👤 **Member Management**: Register members, track borrowed books
- 🔄 **Borrow/Return Operations**: Process book loans and returns
- 🔍 **Search**: Find books by title, author, or ISBN
- 📊 **Statistics**: View library usage statistics
- 💰 **Fine Management**: Calculate and manage overdue fines

### Advanced Features
- ⏰ **Due Date Tracking**: Automatic due date calculation
- 💾 **Data Persistence**: Save/load data to JSON files
- 📋 **Borrow Limits**: Maximum books per member (configurable)
- 🔄 **Backup System**: Automatic data backups
- ✅ **Input Validation**: Robust error handling

## Project Structure
