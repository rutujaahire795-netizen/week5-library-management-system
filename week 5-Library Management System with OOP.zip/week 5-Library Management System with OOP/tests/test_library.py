"""
Unit tests for Library class
"""
import unittest
import sys
import os
import tempfile
import json

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from library_system.library import Library
from library_system.book import Book
from library_system.member import Member

class TestLibrary(unittest.TestCase):
    """Test cases for Library class"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.library = Library("Test Library")
        
        # Add test books
        self.book1 = Book("Book 1", "Author A", "ISBN001", 2020)
        self.book2 = Book("Book 2", "Author B", "ISBN002", 2021)
        self.book3 = Book("Book 3", "Author A", "ISBN003", 2022)
        
        self.library.add_book(self.book1)
        self.library.add_book(self.book2)
        self.library.add_book(self.book3)
        
        # Add test members
        self.member1 = self.library.register_member("Alice", "MEM001")
        self.member2 = self.library.register_member("Bob", "MEM002")
    
    def test_add_book(self):
        """Test adding books to library"""
        book = Book("New Book", "New Author", "ISBN004", 2023)
        result = self.library.add_book(book)
        self.assertTrue(result)
        self.assertEqual(len(self.library.books), 4)
        
        # Try to add duplicate
        result = self.library.add_book(book)
        self.assertFalse(result)
    
    def test_remove_book(self):
        """Test removing books from library"""
        result = self.library.remove_book("ISBN001")
        self.assertTrue(result)
        self.assertEqual(len(self.library.books), 2)
        
        # Try to remove non-existent
        result = self.library.remove_book("ISBN999")
        self.assertFalse(result)
    
    def test_find_book(self):
        """Test finding books by ISBN"""
        book = self.library.find_book("ISBN001")
        self.assertEqual(book, self.book1)
        
        book = self.library.find_book("ISBN999")
        self.assertIsNone(book)
    
    def test_search_books(self):
        """Test searching books"""
        # Search by title
        results = self.library.search_books("Book 1", 'title')
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0], self.book1)
        
        # Search by author
        results = self.library.search_books("Author A", 'author')
        self.assertEqual(len(results), 2)
        
        # Search by ISBN
        results = self.library.search_books("ISBN002", 'isbn')
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0], self.book2)
    
    def test_register_member(self):
        """Test member registration"""
        member = self.library.register_member("Charlie", "MEM003")
        self.assertEqual(member.name, "Charlie")
        self.assertEqual(member.member_id, "MEM003")
        self.assertEqual(len(self.library.members), 3)
        
        # Try to register duplicate ID
        member = self.library.register_member("Duplicate", "MEM003")
        self.assertIsNone(member)
    
    def test_find_member(self):
        """Test finding members by ID"""
        member = self.library.find_member("MEM001")
        self.assertEqual(member, self.member1)
        
        member = self.library.find_member("MEM999")
        self.assertIsNone(member)
    
    def test_borrow_book(self):
        """Test borrowing process"""
        # Successful borrow
        success, message = self.library.borrow_book("MEM001", "ISBN001")
        self.assertTrue(success)
        self.assertFalse(self.book1.available)
        self.assertIn("ISBN001", self.member1.borrowed_books)
        
        # Borrow non-existent book
        success, message = self.library.borrow_book("MEM001", "ISBN999")
        self.assertFalse(success)
        
        # Borrow unavailable book
        success, message = self.library.borrow_book("MEM002", "ISBN001")
        self.assertFalse(success)
        
        # Non-existent member
        success, message = self.library.borrow_book("MEM999", "ISBN001")
        self.assertFalse(success)
    
    def test_return_book(self):
        """Test return process"""
        # Borrow first
        self.library.borrow_book("MEM001", "ISBN001")
        
        # Return successfully
        success, message, fine = self.library.return_book("MEM001", "ISBN001")
        self.assertTrue(success)
        self.assertTrue(self.book1.available)
        self.assertNotIn("ISBN001", self.member1.borrowed_books)
        
        # Return non-borrowed book
        success, message, fine = self.library.return_book("MEM001", "ISBN002")
        self.assertFalse(success)
    
    def test_statistics(self):
        """Test statistics generation"""
        stats = self.library.get_statistics()
        self.assertEqual(stats['total_books'], 3)
        self.assertEqual(stats['available_books'], 3)
        self.assertEqual(stats['borrowed_books'], 0)
        self.assertEqual(stats['total_members'], 2)
        self.assertEqual(stats['active_borrowers'], 0)
        self.assertEqual(stats['overdue_books'], 0)
        
        # Borrow a book
        self.library.borrow_book("MEM001", "ISBN001")
        stats = self.library.get_statistics()
        self.assertEqual(stats['available_books'], 2)
        self.assertEqual(stats['borrowed_books'], 1)
        self.assertEqual(stats['active_borrowers'], 1)
    
    def test_save_and_load(self):
        """Test saving and loading data"""
        # Create temporary files
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as books_f, \
             tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as members_f:
            books_file = books_f.name
            members_file = members_f.name
        
        try:
            # Add some data
            self.library.borrow_book("MEM001", "ISBN001")
            
            # Save data
            self.library.save_data(books_file, members_file)
            
            # Create new library and load data
            new_library = Library("Loaded Library")
            new_library.load_data(books_file, members_file)
            
            # Verify data
            self.assertEqual(len(new_library.books), 3)
            self.assertEqual(len(new_library.members), 2)
            
            book = new_library.find_book("ISBN001")
            self.assertFalse(book.available)
            
        finally:
            # Clean up temporary files
            os.unlink(books_file)
            os.unlink(members_file)

if __name__ == '__main__':
    unittest.main()