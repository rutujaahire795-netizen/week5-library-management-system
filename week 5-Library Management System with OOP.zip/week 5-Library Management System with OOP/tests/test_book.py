"""
Unit tests for Book class
"""
import unittest
import sys
import os
from datetime import datetime, timedelta

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from library_system.book import Book

class TestBook(unittest.TestCase):
    """Test cases for Book class"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.book = Book("Test Book", "Test Author", "1234567890", 2023)
    
    def test_book_creation(self):
        """Test book initialization"""
        self.assertEqual(self.book.title, "Test Book")
        self.assertEqual(self.book.author, "Test Author")
        self.assertEqual(self.book.isbn, "1234567890")
        self.assertEqual(self.book.year, 2023)
        self.assertTrue(self.book.available)
        self.assertIsNone(self.book.borrowed_by)
        self.assertIsNone(self.book.due_date)
    
    def test_check_out(self):
        """Test checking out a book"""
        result = self.book.check_out("MEM001")
        self.assertTrue(result)
        self.assertFalse(self.book.available)
        self.assertEqual(self.book.borrowed_by, "MEM001")
        self.assertIsNotNone(self.book.due_date)
        
        # Try to check out again
        result = self.book.check_out("MEM002")
        self.assertFalse(result)
    
    def test_return_book(self):
        """Test returning a book"""
        self.book.check_out("MEM001")
        result = self.book.return_book()
        self.assertTrue(result)
        self.assertTrue(self.book.available)
        self.assertIsNone(self.book.borrowed_by)
        self.assertIsNone(self.book.due_date)
    
    def test_is_overdue(self):
        """Test overdue checking"""
        self.book.check_out("MEM001", days=1)
        self.assertFalse(self.book.is_overdue())
        
        # Set due date to yesterday
        self.book.due_date = datetime.now() - timedelta(days=1)
        self.assertTrue(self.book.is_overdue())
    
    def test_str_representation(self):
        """Test string representation"""
        self.assertIn("Test Book", str(self.book))
        self.assertIn("Available", str(self.book))
    
    def test_to_dict(self):
        """Test dictionary conversion"""
        self.book.check_out("MEM001")
        data = self.book.to_dict()
        
        self.assertEqual(data['title'], "Test Book")
        self.assertEqual(data['author'], "Test Author")
        self.assertEqual(data['isbn'], "1234567890")
        self.assertEqual(data['year'], 2023)
        self.assertFalse(data['available'])
        self.assertEqual(data['borrowed_by'], "MEM001")
        self.assertIsNotNone(data['due_date'])
    
    def test_from_dict(self):
        """Test object creation from dictionary"""
        self.book.check_out("MEM001")
        data = self.book.to_dict()
        
        new_book = Book.from_dict(data)
        self.assertEqual(new_book.title, "Test Book")
        self.assertEqual(new_book.author, "Test Author")
        self.assertEqual(new_book.isbn, "1234567890")
        self.assertEqual(new_book.year, 2023)
        self.assertFalse(new_book.available)
        self.assertEqual(new_book.borrowed_by, "MEM001")

if __name__ == '__main__':
    unittest.main()