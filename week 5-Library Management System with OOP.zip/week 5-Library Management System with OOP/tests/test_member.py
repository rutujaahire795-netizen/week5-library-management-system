"""
Unit tests for Member class
"""
import unittest
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from library_system.member import Member

class TestMember(unittest.TestCase):
    """Test cases for Member class"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.member = Member("John Doe", "MEM001")
    
    def test_member_creation(self):
        """Test member initialization"""
        self.assertEqual(self.member.name, "John Doe")
        self.assertEqual(self.member.member_id, "MEM001")
        self.assertEqual(self.member.borrowed_books, [])
        self.assertEqual(self.member.fines, 0.0)
        self.assertEqual(self.member.MAX_BORROW_LIMIT, 5)
    
    def test_borrow_book(self):
        """Test borrowing a book"""
        result = self.member.borrow_book("ISBN001")
        self.assertTrue(result)
        self.assertIn("ISBN001", self.member.borrowed_books)
        
        # Try to borrow same book again
        result = self.member.borrow_book("ISBN001")
        self.assertFalse(result)
    
    def test_borrow_limit(self):
        """Test borrow limit"""
        # Borrow up to limit
        for i in range(self.member.MAX_BORROW_LIMIT):
            result = self.member.borrow_book(f"ISBN{i:03d}")
            self.assertTrue(result)
        
        # Try to exceed limit
        result = self.member.borrow_book("ISBN999")
        self.assertFalse(result)
        self.assertEqual(len(self.member.borrowed_books), self.member.MAX_BORROW_LIMIT)
    
    def test_return_book(self):
        """Test returning a book"""
        self.member.borrow_book("ISBN001")
        result = self.member.return_book("ISBN001")
        self.assertTrue(result)
        self.assertNotIn("ISBN001", self.member.borrowed_books)
        
        # Try to return non-borrowed book
        result = self.member.return_book("ISBN999")
        self.assertFalse(result)
    
    def test_fine_management(self):
        """Test fine operations"""
        self.member.add_fine(10.50)
        self.assertEqual(self.member.fines, 10.50)
        
        result = self.member.pay_fine(5.25)
        self.assertTrue(result)
        self.assertEqual(self.member.fines, 5.25)
        
        result = self.member.pay_fine(10.00)
        self.assertFalse(result)  # Exceeds remaining fine
        self.assertEqual(self.member.fines, 5.25)
    
    def test_str_representation(self):
        """Test string representation"""
        self.assertIn("John Doe", str(self.member))
        self.assertIn("MEM001", str(self.member))
        self.assertIn("0/5", str(self.member))
    
    def test_to_dict(self):
        """Test dictionary conversion"""
        self.member.borrow_book("ISBN001")
        data = self.member.to_dict()
        
        self.assertEqual(data['name'], "John Doe")
        self.assertEqual(data['member_id'], "MEM001")
        self.assertIn("ISBN001", data['borrowed_books'])
        self.assertEqual(data['fines'], 0.0)
    
    def test_from_dict(self):
        """Test object creation from dictionary"""
        self.member.borrow_book("ISBN001")
        data = self.member.to_dict()
        
        new_member = Member.from_dict(data)
        self.assertEqual(new_member.name, "John Doe")
        self.assertEqual(new_member.member_id, "MEM001")
        self.assertIn("ISBN001", new_member.borrowed_books)

if __name__ == '__main__':
    unittest.main()