"""
Member module for Library Management System
"""
from datetime import datetime

class Member:
    """Member class representing a library member"""
    
    MAX_BORROW_LIMIT = 5
    
    def __init__(self, name, member_id):
        """
        Initialize a Member object
        
        Args:
            name (str): Member's full name
            member_id (str): Unique member ID
        """
        self.name = name
        self.member_id = member_id
        self.borrowed_books = []  # List of ISBNs
        self.registration_date = datetime.now()
        self.fines = 0.0
    
    def borrow_book(self, isbn):
        """
        Add a book to member's borrowed books
        
        Args:
            isbn (str): ISBN of book to borrow
            
        Returns:
            bool: True if successful, False otherwise
        """
        if len(self.borrowed_books) >= self.MAX_BORROW_LIMIT:
            print(f"Cannot borrow more than {self.MAX_BORROW_LIMIT} books")
            return False
        
        if isbn in self.borrowed_books:
            print("You already have this book")
            return False
        
        self.borrowed_books.append(isbn)
        return True
    
    def return_book(self, isbn):
        """
        Remove a book from member's borrowed books
        
        Args:
            isbn (str): ISBN of book to return
            
        Returns:
            bool: True if successful, False otherwise
        """
        if isbn in self.borrowed_books:
            self.borrowed_books.remove(isbn)
            return True
        return False
    
    def add_fine(self, amount):
        """Add fine to member's account"""
        self.fines += amount
    
    def pay_fine(self, amount):
        """Pay fines"""
        if amount <= self.fines:
            self.fines -= amount
            return True
        return False
    
    def __str__(self):
        """String representation of the member"""
        books_count = len(self.borrowed_books)
        return f"Member: {self.name} (ID: {self.member_id}) - Books: {books_count}/{self.MAX_BORROW_LIMIT} - Fines: ${self.fines:.2f}"
    
    def to_dict(self):
        """Convert member to dictionary for JSON serialization"""
        return {
            'name': self.name,
            'member_id': self.member_id,
            'borrowed_books': self.borrowed_books,
            'registration_date': self.registration_date.isoformat(),
            'fines': self.fines
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create a Member object from dictionary data"""
        member = cls(
            name=data['name'],
            member_id=data['member_id']
        )
        member.borrowed_books = data['borrowed_books']
        member.registration_date = datetime.fromisoformat(data['registration_date'])
        member.fines = data.get('fines', 0.0)
        return member