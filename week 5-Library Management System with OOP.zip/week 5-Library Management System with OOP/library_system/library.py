"""
Library module for Library Management System
"""
import json
import os
from datetime import datetime, timedelta
from .book import Book
from .member import Member

class Library:
    """Library class to manage books and members"""
    
    def __init__(self, name="Main Library"):
        """
        Initialize a Library object
        
        Args:
            name (str): Library name
        """
        self.name = name
        self.books = {}  # ISBN -> Book object
        self.members = {}  # member_id -> Member object
        self.transactions = []  # List of transaction records
    
    # Book Management Methods
    def add_book(self, book):
        """
        Add a book to the library
        
        Args:
            book (Book): Book object to add
            
        Returns:
            bool: True if successful, False if book already exists
        """
        if book.isbn in self.books:
            return False
        self.books[book.isbn] = book
        return True
    
    def remove_book(self, isbn):
        """
        Remove a book from the library
        
        Args:
            isbn (str): ISBN of book to remove
            
        Returns:
            bool: True if successful, False if book not found
        """
        if isbn in self.books:
            del self.books[isbn]
            return True
        return False
    
    def find_book(self, isbn):
        """
        Find a book by ISBN
        
        Args:
            isbn (str): ISBN to search for
            
        Returns:
            Book or None: Found book or None
        """
        return self.books.get(isbn)
    
    def search_books(self, query, search_type='title'):
        """
        Search for books by title, author, or ISBN
        
        Args:
            query (str): Search query
            search_type (str): 'title', 'author', or 'isbn'
            
        Returns:
            list: List of matching books
        """
        results = []
        query = query.lower()
        
        for book in self.books.values():
            if search_type == 'title' and query in book.title.lower():
                results.append(book)
            elif search_type == 'author' and query in book.author.lower():
                results.append(book)
            elif search_type == 'isbn' and query == book.isbn.lower():
                results.append(book)
        
        return results
    
    # Member Management Methods
    def register_member(self, name, member_id):
        """
        Register a new member
        
        Args:
            name (str): Member's name
            member_id (str): Member's ID
            
        Returns:
            Member or None: Created member or None if ID exists
        """
        if member_id in self.members:
            return None
        
        member = Member(name, member_id)
        self.members[member_id] = member
        return member
    
    def find_member(self, member_id):
        """
        Find a member by ID
        
        Args:
            member_id (str): Member ID to search for
            
        Returns:
            Member or None: Found member or None
        """
        return self.members.get(member_id)
    
    # Borrowing Operations
    def borrow_book(self, member_id, isbn):
        """
        Borrow a book from the library
        
        Args:
            member_id (str): ID of member borrowing
            isbn (str): ISBN of book to borrow
            
        Returns:
            tuple: (success, message)
        """
        # Check if member exists
        member = self.find_member(member_id)
        if not member:
            return False, "Member not found"
        
        # Check if book exists
        book = self.find_book(isbn)
        if not book:
            return False, "Book not found"
        
        # Check if book is available
        if not book.available:
            return False, "Book is not available"
        
        # Check member's borrow limit
        if len(member.borrowed_books) >= member.MAX_BORROW_LIMIT:
            return False, f"Member has reached maximum borrow limit ({member.MAX_BORROW_LIMIT})"
        
        # Check member's fines
        if member.fines > 0:
            return False, f"Member has unpaid fines: ${member.fines:.2f}"
        
        # Process borrowing
        book.check_out(member_id)
        member.borrow_book(isbn)
        
        # Record transaction
        self.transactions.append({
            'type': 'borrow',
            'member_id': member_id,
            'isbn': isbn,
            'date': datetime.now().isoformat(),
            'due_date': book.due_date.isoformat()
        })
        
        return True, f"Book '{book.title}' borrowed successfully. Due date: {book.due_date.strftime('%Y-%m-%d')}"
    
    def return_book(self, member_id, isbn):
        """
        Return a borrowed book
        
        Args:
            member_id (str): ID of member returning
            isbn (str): ISBN of book to return
            
        Returns:
            tuple: (success, message, fine)
        """
        # Check if member exists
        member = self.find_member(member_id)
        if not member:
            return False, "Member not found", 0
        
        # Check if book exists
        book = self.find_book(isbn)
        if not book:
            return False, "Book not found", 0
        
        # Check if book was borrowed by this member
        if book.borrowed_by != member_id:
            return False, "This book was not borrowed by this member", 0
        
        # Calculate fine if overdue
        fine = 0
        if book.is_overdue():
            days_overdue = (datetime.now() - book.due_date).days
            fine = days_overdue * 0.50  # $0.50 per day fine
            member.add_fine(fine)
        
        # Process return
        book.return_book()
        member.return_book(isbn)
        
        # Record transaction
        self.transactions.append({
            'type': 'return',
            'member_id': member_id,
            'isbn': isbn,
            'date': datetime.now().isoformat(),
            'fine': fine
        })
        
        message = f"Book '{book.title}' returned successfully"
        if fine > 0:
            message += f". Fine incurred: ${fine:.2f}"
        
        return True, message, fine
    
    # Statistics Methods
    def get_statistics(self):
        """Get library statistics"""
        total_books = len(self.books)
        available_books = sum(1 for book in self.books.values() if book.available)
        borrowed_books = total_books - available_books
        total_members = len(self.members)
        active_borrowers = sum(1 for member in self.members.values() if member.borrowed_books)
        overdue_books = sum(1 for book in self.books.values() if book.is_overdue())
        total_fines = sum(member.fines for member in self.members.values())
        
        return {
            'total_books': total_books,
            'available_books': available_books,
            'borrowed_books': borrowed_books,
            'total_members': total_members,
            'active_borrowers': active_borrowers,
            'overdue_books': overdue_books,
            'total_fines': total_fines
        }
    
    # File Operations
    def save_data(self, books_file='data/books.json', members_file='data/members.json'):
        """
        Save library data to JSON files
        
        Args:
            books_file (str): Path to books JSON file
            members_file (str): Path to members JSON file
        """
        # Create data directory if it doesn't exist
        os.makedirs(os.path.dirname(books_file), exist_ok=True)
        
        # Save books
        books_data = {
            isbn: book.to_dict() for isbn, book in self.books.items()
        }
        with open(books_file, 'w') as f:
            json.dump(books_data, f, indent=2)
        
        # Save members
        members_data = {
            mid: member.to_dict() for mid, member in self.members.items()
        }
        with open(members_file, 'w') as f:
            json.dump(members_data, f, indent=2)
        
        # Create backup
        self.create_backup(books_file, members_file)
    
    def load_data(self, books_file='data/books.json', members_file='data/members.json'):
        """
        Load library data from JSON files
        
        Args:
            books_file (str): Path to books JSON file
            members_file (str): Path to members JSON file
        """
        # Load books
        if os.path.exists(books_file):
            with open(books_file, 'r') as f:
                books_data = json.load(f)
                for isbn, data in books_data.items():
                    self.books[isbn] = Book.from_dict(data)
        
        # Load members
        if os.path.exists(members_file):
            with open(members_file, 'r') as f:
                members_data = json.load(f)
                for mid, data in members_data.items():
                    self.members[mid] = Member.from_dict(data)
    
    def create_backup(self, books_file, members_file, backup_dir='data/backup/'):
        """Create backup of data files"""
        os.makedirs(backup_dir, exist_ok=True)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        if os.path.exists(books_file):
            backup_books = os.path.join(backup_dir, f'books_{timestamp}.json')
            with open(books_file, 'r') as src, open(backup_books, 'w') as dst:
                dst.write(src.read())
        
        if os.path.exists(members_file):
            backup_members = os.path.join(backup_dir, f'members_{timestamp}.json')
            with open(members_file, 'r') as src, open(backup_members, 'w') as dst:
                dst.write(src.read())
    
    def __str__(self):
        """String representation of the library"""
        stats = self.get_statistics()
        return f"{self.name}\n" + \
               f"Books: {stats['total_books']} total, {stats['available_books']} available, {stats['borrowed_books']} borrowed\n" + \
               f"Members: {stats['total_members']} total, {stats['active_borrowers']} active\n" + \
               f"Overdue: {stats['overdue_books']} books, Total fines: ${stats['total_fines']:.2f}"