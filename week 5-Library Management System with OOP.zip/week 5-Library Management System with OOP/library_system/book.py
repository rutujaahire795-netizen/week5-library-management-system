"""
Book module for Library Management System
"""
from datetime import datetime, timedelta

class Book:
    """Book class representing a book in the library"""
    
    def __init__(self, title, author, isbn, year, available=True):
        """
        Initialize a Book object
        
        Args:
            title (str): Book title
            author (str): Book author
            isbn (str): International Standard Book Number
            year (int): Publication year
            available (bool): Availability status
        """
        self.title = title
        self.author = author
        self.isbn = isbn
        self.year = year
        self.available = available
        self.borrowed_by = None
        self.due_date = None
    
    def check_out(self, member_id, days=14):
        """
        Check out the book to a member
        
        Args:
            member_id (str): ID of member borrowing the book
            days (int): Number of days until due
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.available:
            return False
        
        self.available = False
        self.borrowed_by = member_id
        self.due_date = datetime.now() + timedelta(days=days)
        return True
    
    def return_book(self):
        """
        Return the book to library
        
        Returns:
            bool: True if successful
        """
        self.available = True
        self.borrowed_by = None
        self.due_date = None
        return True
    
    def is_overdue(self):
        """
        Check if the book is overdue
        
        Returns:
            bool: True if overdue, False otherwise
        """
        if self.due_date and not self.available:
            return datetime.now() > self.due_date
        return False
    
    def __str__(self):
        """String representation of the book"""
        status = "Available" if self.available else f"Borrowed (Due: {self.due_date.strftime('%Y-%m-%d') if self.due_date else 'Unknown'})"
        return f"'{self.title}' by {self.author} ({self.year}) - ISBN: {self.isbn} - {status}"
    
    def to_dict(self):
        """Convert book to dictionary for JSON serialization"""
        return {
            'title': self.title,
            'author': self.author,
            'isbn': self.isbn,
            'year': self.year,
            'available': self.available,
            'borrowed_by': self.borrowed_by,
            'due_date': self.due_date.isoformat() if self.due_date else None
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create a Book object from dictionary data"""
        book = cls(
            title=data['title'],
            author=data['author'],
            isbn=data['isbn'],
            year=data['year'],
            available=data['available']
        )
        book.borrowed_by = data.get('borrowed_by')
        if data.get('due_date'):
            book.due_date = datetime.fromisoformat(data['due_date'])
        return book