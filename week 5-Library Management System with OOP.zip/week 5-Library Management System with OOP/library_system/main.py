"""
Main module for Library Management System
Provides a command-line interface for library operations
"""
import sys
import os
from datetime import datetime

# Add parent directory to path to allow imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from library_system.book import Book
from library_system.member import Member
from library_system.library import Library

class LibraryManagementSystem:
    """Main application class for Library Management System"""
    
    def __init__(self):
        """Initialize the library management system"""
        self.library = Library("City Central Library")
        self.load_data()
    
    def load_data(self):
        """Load data from files"""
        try:
            self.library.load_data()
            print("Data loaded successfully!")
        except Exception as e:
            print(f"Error loading data: {e}")
            print("Starting with empty library.")
    
    def save_data(self):
        """Save data to files"""
        try:
            self.library.save_data()
            print("Data saved successfully!")
        except Exception as e:
            print(f"Error saving data: {e}")
    
    def display_menu(self):
        """Display the main menu"""
        print("\n" + "="*50)
        print(f"📚 {self.library.name} - Library Management System")
        print("="*50)
        print("1. 📖 Book Management")
        print("2. 👤 Member Management")
        print("3. 🔄 Borrow/Return Operations")
        print("4. 🔍 Search")
        print("5. 📊 Statistics")
        print("6. 💰 Fine Management")
        print("7. 💾 Save Data")
        print("8. 📂 Load Data")
        print("9. 🚪 Exit")
        print("="*50)
    
    def book_management_menu(self):
        """Book management submenu"""
        while True:
            print("\n" + "-"*30)
            print("📖 Book Management")
            print("-"*30)
            print("1. Add a new book")
            print("2. Remove a book")
            print("3. View all books")
            print("4. View available books")
            print("5. View borrowed books")
            print("6. Back to main menu")
            
            choice = input("\nEnter your choice (1-6): ").strip()
            
            if choice == '1':
                self.add_book()
            elif choice == '2':
                self.remove_book()
            elif choice == '3':
                self.display_books()
            elif choice == '4':
                self.display_available_books()
            elif choice == '5':
                self.display_borrowed_books()
            elif choice == '6':
                break
            else:
                print("Invalid choice. Please try again.")
    
    def add_book(self):
        """Add a new book to the library"""
        print("\n--- Add New Book ---")
        title = input("Title: ").strip()
        author = input("Author: ").strip()
        isbn = input("ISBN: ").strip()
        
        try:
            year = int(input("Publication Year: ").strip())
        except ValueError:
            print("Invalid year. Using current year.")
            year = datetime.now().year
        
        book = Book(title, author, isbn, year)
        
        if self.library.add_book(book):
            print(f"✅ Book '{title}' added successfully!")
        else:
            print(f"❌ Book with ISBN {isbn} already exists.")
    
    def remove_book(self):
        """Remove a book from the library"""
        print("\n--- Remove Book ---")
        isbn = input("Enter ISBN of book to remove: ").strip()
        
        book = self.library.find_book(isbn)
        if book:
            print(f"Found: {book}")
            confirm = input("Are you sure you want to remove this book? (y/n): ").strip().lower()
            if confirm == 'y':
                self.library.remove_book(isbn)
                print("✅ Book removed successfully!")
        else:
            print("❌ Book not found.")
    
    def display_books(self):
        """Display all books in the library"""
        print("\n--- All Books ---")
        if not self.library.books:
            print("No books in the library.")
            return
        
        books_list = list(self.library.books.values())
        books_list.sort(key=lambda b: b.title)
        
        for i, book in enumerate(books_list, 1):
            print(f"{i}. {book}")
    
    def display_available_books(self):
        """Display all available books"""
        print("\n--- Available Books ---")
        available_books = [b for b in self.library.books.values() if b.available]
        
        if not available_books:
            print("No books available.")
            return
        
        for i, book in enumerate(available_books, 1):
            print(f"{i}. {book}")
    
    def display_borrowed_books(self):
        """Display all borrowed books"""
        print("\n--- Borrowed Books ---")
        borrowed_books = [b for b in self.library.books.values() if not b.available]
        
        if not borrowed_books:
            print("No books borrowed.")
            return
        
        for i, book in enumerate(borrowed_books, 1):
            status = "⚠️ OVERDUE" if book.is_overdue() else ""
            print(f"{i}. {book} {status}")
    
    def member_management_menu(self):
        """Member management submenu"""
        while True:
            print("\n" + "-"*30)
            print("👤 Member Management")
            print("-"*30)
            print("1. Register new member")
            print("2. View all members")
            print("3. View member details")
            print("4. Back to main menu")
            
            choice = input("\nEnter your choice (1-4): ").strip()
            
            if choice == '1':
                self.register_member()
            elif choice == '2':
                self.display_members()
            elif choice == '3':
                self.view_member_details()
            elif choice == '4':
                break
            else:
                print("Invalid choice. Please try again.")
    
    def register_member(self):
        """Register a new member"""
        print("\n--- Register New Member ---")
        name = input("Full Name: ").strip()
        member_id = input("Member ID: ").strip()
        
        if self.library.find_member(member_id):
            print(f"❌ Member ID {member_id} already exists.")
            return
        
        member = self.library.register_member(name, member_id)
        if member:
            print(f"✅ Member '{name}' registered successfully with ID: {member_id}")
        else:
            print("❌ Registration failed.")
    
    def display_members(self):
        """Display all members"""
        print("\n--- All Members ---")
        if not self.library.members:
            print("No members registered.")
            return
        
        members_list = list(self.library.members.values())
        members_list.sort(key=lambda m: m.name)
        
        for i, member in enumerate(members_list, 1):
            print(f"{i}. {member}")
    
    def view_member_details(self):
        """View detailed information about a member"""
        member_id = input("Enter Member ID: ").strip()
        member = self.library.find_member(member_id)
        
        if not member:
            print("❌ Member not found.")
            return
        
        print(f"\n--- Member Details ---")
        print(f"Name: {member.name}")
        print(f"ID: {member.member_id}")
        print(f"Registered: {member.registration_date.strftime('%Y-%m-%d')}")
        print(f"Fines: ${member.fines:.2f}")
        print(f"Borrowed Books ({len(member.borrowed_books)}/{member.MAX_BORROW_LIMIT}):")
        
        if member.borrowed_books:
            for isbn in member.borrowed_books:
                book = self.library.find_book(isbn)
                if book:
                    status = "⚠️ OVERDUE" if book.is_overdue() else ""
                    print(f"  - {book.title} by {book.author} {status}")
        else:
            print("  No books borrowed")
    
    def borrow_return_menu(self):
        """Borrow/return operations submenu"""
        while True:
            print("\n" + "-"*30)
            print("🔄 Borrow/Return Operations")
            print("-"*30)
            print("1. Borrow a book")
            print("2. Return a book")
            print("3. View overdue books")
            print("4. Back to main menu")
            
            choice = input("\nEnter your choice (1-4): ").strip()
            
            if choice == '1':
                self.borrow_book()
            elif choice == '2':
                self.return_book()
            elif choice == '3':
                self.display_overdue_books()
            elif choice == '4':
                break
            else:
                print("Invalid choice. Please try again.")
    
    def borrow_book(self):
        """Process book borrowing"""
        print("\n--- Borrow a Book ---")
        member_id = input("Member ID: ").strip()
        isbn = input("Book ISBN: ").strip()
        
        success, message = self.library.borrow_book(member_id, isbn)
        
        if success:
            print(f"✅ {message}")
        else:
            print(f"❌ {message}")
    
    def return_book(self):
        """Process book return"""
        print("\n--- Return a Book ---")
        member_id = input("Member ID: ").strip()
        isbn = input("Book ISBN: ").strip()
        
        success, message, fine = self.library.return_book(member_id, isbn)
        
        if success:
            print(f"✅ {message}")
        else:
            print(f"❌ {message}")
    
    def display_overdue_books(self):
        """Display all overdue books"""
        print("\n--- Overdue Books ---")
        overdue_books = [b for b in self.library.books.values() if b.is_overdue()]
        
        if not overdue_books:
            print("No overdue books.")
            return
        
        for i, book in enumerate(overdue_books, 1):
            member = self.library.find_member(book.borrowed_by)
            member_name = member.name if member else "Unknown"
            days_overdue = (datetime.now() - book.due_date).days
            print(f"{i}. {book.title} by {book.author}")
            print(f"   Borrowed by: {member_name} (ID: {book.borrowed_by})")
            print(f"   Due: {book.due_date.strftime('%Y-%m-%d')} ({days_overdue} days overdue)")
    
    def search_menu(self):
        """Search operations submenu"""
        while True:
            print("\n" + "-"*30)
            print("🔍 Search")
            print("-"*30)
            print("1. Search by title")
            print("2. Search by author")
            print("3. Search by ISBN")
            print("4. Back to main menu")
            
            choice = input("\nEnter your choice (1-4): ").strip()
            
            if choice in ['1', '2', '3']:
                query = input("Enter search query: ").strip()
                
                search_types = {'1': 'title', '2': 'author', '3': 'isbn'}
                results = self.library.search_books(query, search_types[choice])
                
                print(f"\nFound {len(results)} results:")
                for i, book in enumerate(results, 1):
                    print(f"{i}. {book}")
            elif choice == '4':
                break
            else:
                print("Invalid choice. Please try again.")
    
    def statistics_menu(self):
        """Display library statistics"""
        print("\n" + "-"*30)
        print("📊 Library Statistics")
        print("-"*30)
        
        stats = self.library.get_statistics()
        
        print(f"Total Books: {stats['total_books']}")
        print(f"Available Books: {stats['available_books']}")
        print(f"Borrowed Books: {stats['borrowed_books']}")
        print(f"Total Members: {stats['total_members']}")
        print(f"Active Borrowers: {stats['active_borrowers']}")
        print(f"Overdue Books: {stats['overdue_books']}")
        print(f"Total Fines: ${stats['total_fines']:.2f}")
        
        input("\nPress Enter to continue...")
    
    def fine_management_menu(self):
        """Fine management submenu"""
        while True:
            print("\n" + "-"*30)
            print("💰 Fine Management")
            print("-"*30)
            print("1. View member fines")
            print("2. Pay fines")
            print("3. Back to main menu")
            
            choice = input("\nEnter your choice (1-3): ").strip()
            
            if choice == '1':
                self.view_member_fines()
            elif choice == '2':
                self.pay_fines()
            elif choice == '3':
                break
            else:
                print("Invalid choice. Please try again.")
    
    def view_member_fines(self):
        """View fines for a specific member"""
        member_id = input("Enter Member ID: ").strip()
        member = self.library.find_member(member_id)
        
        if not member:
            print("❌ Member not found.")
            return
        
        print(f"\n--- Fines for {member.name} ---")
        print(f"Total Fines: ${member.fines:.2f}")
        
        if member.fines > 0:
            print("\nOverdue books contributing to fines:")
            for isbn in member.borrowed_books:
                book = self.library.find_book(isbn)
                if book and book.is_overdue():
                    days_overdue = (datetime.now() - book.due_date).days
                    fine = days_overdue * 0.50
                    print(f"  - {book.title}: {days_overdue} days overdue (${fine:.2f})")
    
    def pay_fines(self):
        """Process fine payment"""
        member_id = input("Enter Member ID: ").strip()
        member = self.library.find_member(member_id)
        
        if not member:
            print("❌ Member not found.")
            return
        
        print(f"\n--- Pay Fines for {member.name} ---")
        print(f"Current fines: ${member.fines:.2f}")
        
        if member.fines <= 0:
            print("No fines to pay.")
            return
        
        try:
            amount = float(input("Enter payment amount: $").strip())
        except ValueError:
            print("Invalid amount.")
            return
        
        if member.pay_fine(amount):
            print(f"✅ Payment of ${amount:.2f} accepted. Remaining fines: ${member.fines:.2f}")
        else:
            print("❌ Payment amount exceeds fines or invalid.")
    
    def run(self):
        """Main application loop"""
        print("\n" + "="*50)
        print("📚 Welcome to the Library Management System!")
        print("="*50)
        
        while True:
            self.display_menu()
            choice = input("\nEnter your choice (1-9): ").strip()
            
            if choice == '1':
                self.book_management_menu()
            elif choice == '2':
                self.member_management_menu()
            elif choice == '3':
                self.borrow_return_menu()
            elif choice == '4':
                self.search_menu()
            elif choice == '5':
                self.statistics_menu()
            elif choice == '6':
                self.fine_management_menu()
            elif choice == '7':
                self.save_data()
            elif choice == '8':
                self.load_data()
            elif choice == '9':
                print("\nSaving data before exit...")
                self.save_data()
                print("Thank you for using the Library Management System!")
                print("Goodbye! 👋")
                break
            else:
                print("Invalid choice. Please enter a number between 1 and 9.")

def main():
    """Main entry point"""
    try:
        app = LibraryManagementSystem()
        app.run()
    except KeyboardInterrupt:
        print("\n\nProgram interrupted. Saving data...")
        if 'app' in locals():
            app.save_data()
        print("Goodbye!")
    except Exception as e:
        print(f"\nAn error occurred: {e}")
        print("Please check the logs and try again.")

if __name__ == "__main__":
    main()